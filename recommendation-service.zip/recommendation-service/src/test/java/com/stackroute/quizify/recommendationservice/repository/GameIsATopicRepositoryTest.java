//package com.stackroute.quizify.recommendationservice.repository;
//
//import org.junit.After;
//import org.junit.Before;
//
//import static org.junit.Assert.*;
//
//public class GameIsATopicRepositoryTest {
//
//    @Before
//    public void setUp() throws Exception {
//    }
//
//    @After
//    public void tearDown() throws Exception {
//    }
//}