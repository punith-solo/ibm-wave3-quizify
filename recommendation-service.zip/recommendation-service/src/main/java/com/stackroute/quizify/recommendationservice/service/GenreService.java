package com.stackroute.quizify.recommendationservice.service;

import com.stackroute.quizify.recommendationservice.domain.Genre;

import java.util.List;

public interface GenreService {

    public List<Genre> getAll();

    List<Genre> getGenresByCategory(long categoryId);
}
