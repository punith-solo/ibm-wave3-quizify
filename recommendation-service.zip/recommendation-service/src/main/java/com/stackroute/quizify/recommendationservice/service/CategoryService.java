package com.stackroute.quizify.recommendationservice.service;

import com.stackroute.quizify.recommendationservice.domain.Category;

import java.util.List;

public interface CategoryService {

    public List<Category> getAll();
}
