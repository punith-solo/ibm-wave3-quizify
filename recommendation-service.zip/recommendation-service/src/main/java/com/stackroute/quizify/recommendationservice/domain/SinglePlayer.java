package com.stackroute.quizify.recommendationservice.domain;

import lombok.Data;

@Data
public class SinglePlayer {
    private Game game;
    private long userId;
}
